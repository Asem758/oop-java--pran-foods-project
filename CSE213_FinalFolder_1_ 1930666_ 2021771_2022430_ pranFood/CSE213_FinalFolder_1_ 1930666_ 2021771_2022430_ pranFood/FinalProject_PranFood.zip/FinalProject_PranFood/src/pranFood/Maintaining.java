
package mainpkg;

/**
 *
 * @author Windows
 */
public class Maintaining extends AccountingManager {
    
}
