
package mainpkg;

public class Academic extends AccountingManager{
    
}
