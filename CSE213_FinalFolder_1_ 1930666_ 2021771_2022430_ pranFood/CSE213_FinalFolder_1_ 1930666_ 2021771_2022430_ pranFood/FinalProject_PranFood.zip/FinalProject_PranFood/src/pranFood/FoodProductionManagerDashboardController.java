/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pranFood;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author intes
 */
public class FoodProductionManagerDashboardController implements Initializable {

    @FXML
    private Button analysisandCreateReportButton;
    @FXML
    private Button viewProfileButton;
    @FXML
    private VBox logoutButton;
    @FXML
    private Button dailyOperationsButton;
    @FXML
    private Button determineprivescheduleButton;
    @FXML
    private Button generatesleadsamongSRButton;
    @FXML
    private Button allocatesalesactivitiesButton;
    @FXML
    private Button nextButton;
    @FXML
    private RadioButton generatingleadsamongSRRadioButton;
    @FXML
    private RadioButton recruitSRRadioButton;
    @FXML
    private RadioButton trainingSRRadioButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    



    @FXML
    private void analysisandCreateReportButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void dailyOperationsButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void generatesleadsamongSRButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void allocatesalesactivitiesButtononclick(ActionEvent event) {
    }

    @FXML
    private void viewProfileButtonOnClick(ActionEvent event) {
    }


    @FXML
    private void determineprivescheduleButtonOnClick(ActionEvent event) {
    }


    @FXML
    private void nextButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void logoutButtonOnClick(MouseEvent event) {
    }

    @FXML
    private void selectgeneratingleadsamongSR(ActionEvent event) {
    }

    @FXML
    private void selectrecruitSR(ActionEvent event) {
    }

    @FXML
    private void selectTrainingSR(ActionEvent event) {
    }



    
}
