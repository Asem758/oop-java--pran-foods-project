
package mainpkg;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class AccountingmanagerHomeSceneController implements Initializable {

    @FXML
    private Label HeadLineLabel;

   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void HomeButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void MaintainingButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void AcademicButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void TaskManagementButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void TaxButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void ProfileButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void ActivityDisplayButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void SignOutButtonOnClick(ActionEvent event) {
    }
    
}
