 

package mainpkg;


public class Manegerial extends FoodControllingManager{
    
}
