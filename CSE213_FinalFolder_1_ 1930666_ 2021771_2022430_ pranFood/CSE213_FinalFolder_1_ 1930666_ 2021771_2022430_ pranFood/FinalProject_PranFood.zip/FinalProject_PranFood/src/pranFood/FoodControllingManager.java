
package mainpkg;

import java.io.Serializable;


public class FoodControllingManager extends Employee implements Serializable{
    
}
