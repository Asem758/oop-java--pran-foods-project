
package mainpkg;


public class Monitoring extends FoodControllingManager{
    
}
