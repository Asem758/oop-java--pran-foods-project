
package mainpkg;

public class Training extends FoodControllingManager{
    
}
