
package mainpkg;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;


public class FoodControllingManagerDefaultSceneController implements Initializable {

    @FXML
    private Label HeadLineLabel;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void HomeButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void PlanningandDevelopmentButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void ControllButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void MonitoringButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void MenegerialButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void TrainingButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void ProfileButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void SignOutButtonOnClick(ActionEvent event) {
    }
    
}
