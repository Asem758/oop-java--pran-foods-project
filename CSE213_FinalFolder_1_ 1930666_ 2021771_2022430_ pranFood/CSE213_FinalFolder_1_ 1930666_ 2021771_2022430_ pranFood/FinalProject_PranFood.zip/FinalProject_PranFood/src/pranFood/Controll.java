
package mainpkg;


public class Controll extends FoodControllingManager{
    
}
