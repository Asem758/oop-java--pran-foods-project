
package mainpkg;

import java.io.Serializable;


public class AccountingManager extends Employee implements Serializable{
    
}
